package lib;
$VERSION = '0.63';
# This fake package exists only for PAUSE indexing purposes!
0;

